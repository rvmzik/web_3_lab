# blog/views.py
from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView
from .models import Post
from .forms import PostForm

# Классовое представление для списка постов
class PostListView(ListView):
    model = Post
    template_name = 'blog/post_list.html'
    context_object_name = 'posts'

    def get_queryset(self):
        # Получаем только опубликованные посты (предполагается, что это метод модели Post)
        return Post.objects.published()

# Классовое представление для отображения одного поста
class PostDetailView(DetailView):
    model = Post
    template_name = 'blog/post_detail.html'
    pk_url_kwarg = 'post_id'  # Указываем, что переменная в URL будет 'post_id'

def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('post_list')
    else:
        form = PostForm()

    return render(request, 'blog/post_form.html', {'form': form})
